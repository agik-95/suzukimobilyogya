
$(document).ready(function () {
    $("#myDIV").click(function () {
        $("#side").slideToggle(1500);
    })
})
function myFunction() {

}
